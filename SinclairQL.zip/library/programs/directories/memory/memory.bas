100 REMark ============================================
110 REMark   MEMORY (Simon) for Sinclair QL
120 REMark   SuperBASIC - MODE 4 (512x256, 4 colours)
130 REMark   Controls: cursor keys (up/down/left/right)
140 REMark   (C) original LOGI'STICK 84, QL port 2026
150 REMark ============================================
160 :
170 MODE 4
180 :
190 REMark --- Open channels ---
200 REMark #2 = graphics window (top area)
210 REMark #0 = text console (bottom strip)
220 OPEN #2,scr_512x200a0x0
230 PAPER #2,0 : INK #2,7 : CLS #2
240 WINDOW #0,512,56,0,200
250 PAPER #0,0 : INK #0,7 : CLS #0
260 CSIZE #0,2,0
270 :
280 REMark --- Constants for square positions ---
290 REMark Each square is 60x60 pixels, arranged in a cross
300 REMark Centre of cross at (256, 100) in #2
310 REMark Positions: top, right, bottom, left
320 LET sz = 60 : REMark square size
330 LET cx = 256 : LET cy = 100 : REMark centre of cross
340 LET gap = 6 : REMark gap between squares
350 :
360 REMark Square top-left corners (x, y):
370 REMark 1=Up, 2=Right, 3=Down, 4=Left
380 DIM sq_x(4), sq_y(4)
390 sq_x(1) = cx - sz/2 : sq_y(1) = cy - sz - gap
400 sq_x(2) = cx + gap   : sq_y(2) = cy - sz/2
410 sq_x(3) = cx - sz/2 : sq_y(3) = cy + gap
420 sq_x(4) = cx - sz - gap : sq_y(4) = cy - sz/2
430 :
440 REMark Colours for each face when lit:
450 REMark 1=Up -> white(7), 2=Right -> red(2)
460 REMark 3=Down -> green(4), 4=Left -> red+stipple
470 DIM sq_c(4)
480 sq_c(1) = 7 : sq_c(2) = 2 : sq_c(3) = 4 : sq_c(4) = 7
490 :
500 REMark BEEP parameters for each face (pitch)
510 DIM bp(4)
520 bp(1) = 10 : bp(2) = 20 : bp(3) = 30 : bp(4) = 40
530 :
540 REMark =============================
550 REMark   TITLE SCREEN
560 REMark =============================
570 :
580 REMark Draw concentric circles
590 FOR i = 5 TO 60 STEP 4
600   CIRCLE #2, 130, 100, i
610   CIRCLE #2, 382, 100, i
620 END FOR i
630 FOR i = 5 TO 60 STEP 3
640   CIRCLE #2, 256, 100, i
650 END FOR i
660 :
670 REMark Scrolling title text
680 LET t$ = "        MEMORY * SIMON GAME FOR SINCLAIR QL        "
690 FOR i = 1 TO LEN(t$) - 20
700   AT #0, 1, 4 : PRINT #0, t$(i TO i+19)
710   PAUSE 5
720 END FOR i
730 :
740 REMark Wait for keypress to start
750 AT #0, 3, 6 : PRINT #0, "PRESS ANY KEY TO START"
760 PAUSE : CLS #0
770 :
780 REMark =============================
790 REMark   GAME INITIALISATION
800 REMark =============================
810 :
820 DEFine PROCedure start_game
830   CLS #2 : CLS #0
840   RANDOMISE DATE
850   LET max_turns = 30
860   LET dly = 60 : REMark initial delay (decreases)
870   DIM seq(max_turns)
880   :
890   REMark Generate random sequence
900   FOR i = 1 TO max_turns
910     seq(i) = RND(1 TO 4)
920   END FOR i
930   :
940   REMark Draw the 4 squares (outlines only)
950   draw_board
960   :
970   REMark Show instructions
980   AT #0, 0, 2
990   PRINT #0, "USE CURSOR KEYS TO REPEAT THE SEQUENCE"
1000   PAUSE 80 : AT #0, 0, 0 : PRINT #0, FILL$(" ",50)
1010   :
1020   REMark =============================
1030   REMark   MAIN GAME LOOP
1040   REMark =============================
1050   :
1060   FOR turn = 1 TO max_turns
1070     :
1080     REMark --- Machine plays sequence ---
1090     AT #0, 0, 10 : PRINT #0, "ROUND: "; turn
1100     PAUSE 30
1110     :
1120     FOR k = 1 TO turn
1130       light_on seq(k)
1140       BEEP 2000, bp(seq(k))
1150       PAUSE dly
1160       light_off seq(k)
1170       PAUSE 8
1180     END FOR k
1190     :
1200     REMark --- Player repeats sequence ---
1210     AT #0, 0, 0 : PRINT #0, FILL$(" ",50)
1220     AT #0, 0, 14 : PRINT #0, "YOUR TURN!"
1230     :
1240     FOR p = 1 TO turn
1250       LET g = get_key
1260       light_on g
1270       BEEP 2000, bp(g)
1280       PAUSE 10
1290       light_off g
1300       :
1310       IF g <> seq(p) THEN
1320         REMark Wrong answer!
1330         BEEP 8000, 80
1340         AT #0, 0, 0 : PRINT #0, FILL$(" ",50)
1350         AT #0, 0, 10 : PRINT #0, "WRONG! SCORE: "; turn - 1
1360         PAUSE 100
1370         GO TO 2000
1380       END IF
1390     END FOR p
1400     :
1410     REMark --- Round passed ---
1420     AT #0, 0, 0 : PRINT #0, FILL$(" ",50)
1430     dly = dly - 2 : IF dly < 15 THEN dly = 15
1440   END FOR turn
1450   :
1460   REMark --- Player won all 30 rounds! ---
1470   FOR i = 1 TO 20
1480     BEEP 1000, i*3
1490   END FOR i
1500   AT #0, 0, 6 : PRINT #0, "PERFECT! YOU COMPLETED ALL 30 ROUNDS!"
1510   PAUSE 150
1520 END DEFine start_game
1530 :
1540 REMark =============================
1550 REMark   PROCEDURES
1560 REMark =============================
1570 :
1580 DEFine PROCedure draw_board
1590   REMark Draw the 4 squares as outlines
1600   INK #2, 7
1610   FOR n = 1 TO 4
1620     LINE #2, sq_x(n), sq_y(n) TO sq_x(n)+sz, sq_y(n)
1630     LINE #2, sq_x(n)+sz, sq_y(n) TO sq_x(n)+sz, sq_y(n)+sz
1640     LINE #2, sq_x(n)+sz, sq_y(n)+sz TO sq_x(n), sq_y(n)+sz
1650     LINE #2, sq_x(n), sq_y(n)+sz TO sq_x(n), sq_y(n)
1660   END FOR n
1670   :
1680   REMark Labels
1690   CSIZE #2, 1, 0
1700   CURSOR #2, sq_x(1)+22, sq_y(1)-12 : PRINT #2, "UP"
1710   CURSOR #2, sq_x(2)+sz+8, sq_y(2)+26 : PRINT #2, "RT"
1720   CURSOR #2, sq_x(3)+18, sq_y(3)+sz+10 : PRINT #2, "DN"
1730   CURSOR #2, sq_x(4)-30, sq_y(4)+26 : PRINT #2, "LT"
1740 END DEFine draw_board
1750 :
1760 DEFine PROCedure light_on(face)
1770   REMark Fill the square with its colour
1780   IF face = 4 THEN
1790     REMark 4th face uses stipple (striped white)
1800     BLOCK #2, sz-2, sz-2, sq_x(face)+1, sq_y(face)+1, 2
1810   ELSE
1820     BLOCK #2, sz-2, sz-2, sq_x(face)+1, sq_y(face)+1, sq_c(face)
1830   END IF
1840 END DEFine light_on
1850 :
1860 DEFine PROCedure light_off(face)
1870   REMark Erase the square interior (back to black)
1880   BLOCK #2, sz-2, sz-2, sq_x(face)+1, sq_y(face)+1, 0
1890 END DEFine light_off
1900 :
1910 DEFine FuNction get_key
1920   REMark Wait for a valid cursor key press
1930   REMark Returns 1=up, 2=right, 3=down, 4=left
1940   LOCal k$, result
1950   REPeat lp
1960     k$ = INKEY$(#0, -1)
1970     SELect ON CODE(k$)
1980       = 208 : result = 1 : EXIT lp : REMark cursor up
1990       = 216 : result = 3 : EXIT lp : REMark cursor down
2000       = 192 : result = 4 : EXIT lp : REMark cursor left
2010       = 200 : result = 2 : EXIT lp : REMark cursor right
2020     END SELect
2030   END REPeat lp
2040   RETurn result
2050 END DEFine get_key
2060 :
2070 REMark =============================
2080 REMark   REPLAY MENU
2090 REMark =============================
2100 :
2000 REMark --- End of game / Replay ---
2010 CLS #0
2020 AT #0, 0, 6 : PRINT #0, "PLAY AGAIN? (Y/N)"
2030 REPeat ask
2040   LET a$ = INKEY$(#0, -1)
2050   IF a$ == "y" OR a$ == "Y" THEN
2060     CLS #2 : CLS #0
2070     start_game
2080   END IF
2090   IF a$ == "n" OR a$ == "N" THEN
2100     CLS #2 : CLS #0
2110     AT #0, 1, 10 : PRINT #0, "GOODBYE!"
2120     BEEP 5000, 50
2130     PAUSE 50
2140     CLOSE #2
2150     EXIT ask
2160   END IF
2170 END REPeat ask
2180 :
2190 REMark --- Start the game ---
2200 start_game
