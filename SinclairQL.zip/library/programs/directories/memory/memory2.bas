100 REMark ==============================
110 REMark   MEMORY (Simon) for QL
120 REMark   MODE 8 - Structured version
130 REMark ==============================
140 :
150 MODE 8
160 OPEN #2,scr_512x200a0x0
170 PAPER #2,0 : INK #2,7 : CLS #2
180 WINDOW #0,512,56,0,200
190 PAPER #0,0 : INK #0,7 : CLS #0
200 :
210 DIM seq(30)
220 RANDOMISE DATE
230 :
240 title_screen
250 init_game
260 :
270 REMark === Main game loop ===
280 FOR round = 1 TO 30
290   delay = 300 - (round * 8)
300   IF delay < 50 THEN delay = 50
310   add_to_sequence round
320   play_sequence round, delay
330   ok = get_player_input(round)
340   IF ok = 0 THEN
350     game_over
360     EXIT round
370   END IF
380 END FOR round
390 :
400 IF ok = 1 THEN victory
410 ask_replay
420 CLOSE #2
430 STOP
440 :
450 :
500 REMark ==============================
510 REMark   TITLE SCREEN
520 REMark ==============================
530 DEFine PROCedure title_screen
540   CLS #2: INK #2,4
550   CSIZE #2,3,1: AT #2,1,13  : PRINT #2,"MEMORY"                 : REMark 32w 2h
560   CSIZE #2,2,1: AT #2,3,10  : PRINT #2,"A tribute to SIMON game": REMark 42w 2h
570   CSIZE #2,2,0: AT #2,10,11 : PRINT #2,"RPUFOS Game Jam 2026"   : REMark 42w 1h
580   CSIZE #2,3,0: AT #2,14,9  : PRINT #2,"Press any key"          : REMark 32w 1h
590   PAUSE
600   CLS #2
610 END DEFine title_screen
620 :
630 :
700 REMark ==============================
710 REMark   INITIALISE GAME
720 REMark ==============================
730 DEFine PROCedure init_game
740   CLS #2: CLS #0
750   draw_board
760   AT #0,2,0 : PRINT #0,"  Use cursor keys to repeat the sequence"
770 END DEFine init_game
780 :
790 :
800 REMark ==============================
810 REMark   DRAW THE BOARD
820 REMark ==============================
830 DEFine PROCedure draw_board
840   LOCal i
850   INK #2,7
855   CIRCLE #2,95,50,45
860   REMark --- Up square green ---
870   INK #2,4: LINE #2,83,90 TO 107,90 TO 107,66 TO 83,66 TO 83,90
880   REMark --- Down square blue ---
890   INK #2,1: LINE #2,83,34 TO 107,34 TO 107,10 TO 83,10 TO 83,34
900   REMark --- Left square yellow ---
910   INK #2,6: LINE #2,55,37 TO 79,37 TO 79,61 TO 55,61 TO 55,37
920   REMark --- Right square red ---
930   INK #2,2: LINE #2,111,37 TO 135,37 TO 135,61 TO 111,61 TO 111,37
940 END DEFine draw_board
980 :
990 :
1000 REMark ==============================
1010 REMark   ADD RANDOM ELEMENT TO SEQUENCE
1020 REMark ==============================
1030 DEFine PROCedure add_to_sequence(r)
1040   seq(r) = RND(1 TO 4)
1050 END DEFine add_to_sequence
1060 :
1070 :
1100 REMark ==============================
1110 REMark   PLAY SEQUENCE (MACHINE TURN)
1120 REMark ==============================
1130 DEFine PROCedure play_sequence(r, d)
1140   LOCal k, w
1150   PAUSE 30
1160   FOR k = 1 TO r
1170     light_on seq(k)
1180     snd seq(k), 8
1190     PAUSE d / 10
1200     light_off seq(k)
1210     PAUSE 5
1220   END FOR k
1230 END DEFine play_sequence
1240 :
1250 :
1300 REMark ==============================
1310 REMark   GET PLAYER INPUT
1320 REMark   Returns 1 if correct, 0 if wrong
1330 REMark ==============================
1340 DEFine FuNction get_player_input(r)
1350   LOCal i, k$, g
1360   FOR i = 1 TO r
1370     REPeat loop
1380       k$ = INKEY$(#0,-1)
1390       g = key_to_dir(k$)
1400       IF g > 0 THEN EXIT loop
1410     END REPeat loop
1420     light_on g
1430     snd g, 5
1440     PAUSE 5
1450     light_off g
1460     IF g <> seq(i) THEN
1470       RETurn 0
1480     END IF
1490   END FOR i
1500   RETurn 1
1510 END DEFine get_player_input
1520 :
1530 :
1600 REMark ==============================
1610 REMark   CONVERT KEYPRESS TO DIRECTION
1620 REMark   1=Up, 2=Down, 3=Left, 4=Right
1630 REMark ==============================
1640 DEFine FuNction key_to_dir(k$)
1650   LOCal c
1660   c = CODE(k$)
1670   SELect ON c
1680     = 208 : RETurn 1 : REMark Cursor UP
1690     = 216 : RETurn 2 : REMark Cursor DOWN
1700     = 192 : RETurn 3 : REMark Cursor LEFT
1710     = 200 : RETurn 4 : REMark Cursor RIGHT
1720     = REMAINDER : RETurn 0
1730   END SELect
1740 END DEFine key_to_dir
1750 :
1760 :
1800 REMark ==============================
1810 REMark   LIGHT ON A SQUARE
1820 REMark ==============================
1830 DEFine PROCedure light_on(direction)
1840   SELect ON direction
1850     = 1 : BLOCK #2,60,44,226,22 ,4  : REMark Up    = green
1860     = 2 : BLOCK #2,60,44,226,134,1  : REMark Down  = blue
1870     = 3 : BLOCK #2,60,44,152,80 ,6  : REMark Left  = yellow
1880     = 4 : BLOCK #2,60,44,302,80 ,2  : REMark Right = red
1890   END SELect
1900 END DEFine light_on
1910 :
1920 :
1950 REMark ==============================
1960 REMark   LIGHT OFF A SQUARE (ERASE)
1970 REMark ==============================
1980 DEFine PROCedure light_off(direction)
1990   SELect ON direction
2000     = 1 : BLOCK #2,60,44,226,22 ,0
2010     = 2 : BLOCK #2,60,44,226,134,0
2020     = 3 : BLOCK #2,60,44,152,80 ,0
2030     = 4 : BLOCK #2,60,44,302,80 ,0
2040   END SELect
2050 END DEFine light_off
2060 :
2070 :
2100 REMark ==============================
2110 REMark   PLAY SOUND
2120 REMark ==============================
2130 DEFine PROCedure snd(in, dur)
2132   LOCal x
2135   x=in: REMark need improvment
2140   SELect ON x
2150     = 1 : BEEP dur*500,73,0,0,0,0,0,0
2160     = 2 : BEEP dur*500,53,0,0,0,0,0,0
2170     = 3 : BEEP dur*500,33,0,0,0,0,0,0
2180     = 4 : BEEP dur*500,93,0,0,0,0,0,0
2190   END SELect
2200 END DEFine snd
2210 :
2220 :
2300 REMark ==============================
2310 REMark   GAME OVER
2320 REMark ==============================
2330 DEFine PROCedure game_over
2340   BEEP 20000,20,0,0,0,0,0,0
2350   CLS #0
2360   INK #0,2: CSIZE #0,3,1: AT #0,0,13: PRINT #0,"WRONG!": PAUSE: CLS #0
2362   INK #0,7: CSIZE #0,2,0: PRINT #0,"You reached round ";round-1
2365   AT #0,3,14: PRINT #0,"Press any key";
2370   PAUSE
2380 END DEFine game_over
2390 :
2400 :
2450 REMark ==============================
2460 REMark   VICTORY
2470 REMark ==============================
2480 DEFine PROCedure victory
2490   LOCal i
2500   FOR i = 1 TO 10
2510     BEEP 2000, i*10, 0,0,0,0,0,0
2520   END FOR i
2530   CLS #0
2540   AT #0,0,0 : PRINT #0,"PERFECT! You completed all 30 rounds!"
2545   AT #0,1,0 : PRINT #0,"Press any key";
2550   PAUSE
2560 END DEFine victory
2570 :
2580 :
2600 REMark ==============================
2610 REMark   ASK REPLAY
2620 REMark ==============================
2630 DEFine PROCedure ask_replay
2640   LOCal k$
2650   CLS #0
2660   AT #0,0,0 : PRINT #0,"Play again? (Y/N)"
2670   REP wait
2680     k$ = INKEY$(#0,-1)
2690     IF k$ == "Y" OR k$ == "y" THEN
2700       init_game
2710       FOR round = 1 TO 30
2720         delay = 300 - (round * 8)
2730         IF delay < 50 THEN delay = 50
2740         add_to_sequence round
2750         play_sequence round, delay
2760         ok = get_player_input(round)
2770         IF ok = 0 THEN
2780           game_over
2790           EXIT round
2800         END IF
2810       END FOR round
2820       IF ok = 1 THEN victory
2830       CLS #0
2840       AT #0,0,0 : PRINT #0,"Play again? (Y/N)"
2850     ELSE IF k$ == "N" OR k$ == "n" THEN
2860       EXIT wait
2870     END IF
2880   END REP wait
2890   CLS #0
2900   AT #0,0,0 : PRINT #0,"Goodbye!"
2910   PAUSE 50
2920 END DEFine ask_replay
